export default function Dashboard(){
 return(<>
 <h1>Welcome admin</h1>
 </>
    
 )
}