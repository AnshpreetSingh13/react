import axios from "axios"
import { useState } from "react"
import { toast } from "react-toastify"
export default function Login(){
  const[email,setemail]=useState("")
  const[password,setpassword]=useState("")
  const handleform=(e)=>{
    e.preventDefault()
    console.log(email);
    console.log(password);
  
  let data={
    email:email,
    password:password
  }
  axios.post("http://localhost:5000/apis/user/login",data).then((res)=>{
    toast.success(res.data.message)
    // sessionStorage.setItem("email",res.data.data.email)
    // sessionStorage.setItem("usertype",res.data.data.userType)
    // sessionStorage.setItem("userId",res.data.data._id)
    // sessionStorage.setItem("token",res.data.data.token)
    // sessionStorage.setItem("islogin",true)

  }).catch((err)=>{
    toast.error("Login failed. Please check your credentials or try again later.")
    console.error(err)
  })
}
    return(
    
        
        <>
  
  {/* Header Start */}
  <div
    className="jumbotron jumbotron-fluid page-header position-relative overlay-bottom"
    style={{ marginBottom: 90 }}
  >
    <div className="container text-center py-5">
      <h1 className="text-white display-1">Login</h1>
      <div className="d-inline-flex text-white mb-5">
        <p className="m-0 text-uppercase">
          <a className="text-white" href="">
            Home
          </a>
        </p>
        <i className="fa fa-angle-double-right pt-1 px-3" />
        <p className="m-0 text-uppercase">Login</p>
      </div>
    </div>
  </div>
  {/* Header End */}
  {/* Login Start */}
  <div className="container-fluid py-5 d-flex align-items-center justify-content-center" style={{ minHeight: '60vh' }}>
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-lg-4">
          <div className="section-title position-relative mb-4 text-center">
            <h6 className="d-inline-block position-relative text-secondary text-uppercase pb-2">
              Login
            </h6>
            <h1 className="display-4">Sign In to Your Account</h1>
          </div>
          <div className="contact-form">
            <form onSubmit={handleform}>
              <div className="form-group">
                <input
                  type="email"
                  className="form-control border-top-0 border-right-0 border-left-0 p-0"
                  placeholder="Your Email"
                  required="required"
                  value={email}
                  onChange={(e)=>{
                    setemail(e.target.value)
                  }
                  }
                />
              </div>
              <div className="form-group">
                <input
                  type="password"
                  className="form-control border-top-0 border-right-0 border-left-0 p-0"
                  placeholder="Your Password"
                  required="required"
                  value={password}
                  onChange={(e)=>{
                    setpassword(e.target.value)
                  }}
                />
              </div>
              <div className="text-center">
                <button className="btn btn-primary py-3 px-5" type="submit">
                  Login
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* Login End */}
  
</>

       

  


       


    )
}