import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Header from './layout/Header'
import Footer from './layout/Footer'
import Home from './components/Home'
import About from './components/About'
import Master from './layout/Master'
import Contact from './components/Contact'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import AdminMaster from './Admin/layout/AdminMaster'
import Dashboard from './Admin/components/Dashboard'
import AdminAbout from './Admin/layout/AdminAbout'
import Login from './components/login'
import { toast } from 'react-toastify/unstyled'
import { ToastContainer } from 'react-toastify'


export default function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <BrowserRouter>
      <Routes>
       <Route path="/" element={<Master/>}>
       <Route path="/" element={<Home/>}></Route>
       <Route path="/about" element={<About/>}></Route>
       <Route path="/contact" element={<Contact/>}></Route>
       <Route path="/login" element={<Login/>}></Route>
       
      </Route>
      <Route path="/admin" element={<AdminMaster/>}>
        <Route path="/admin" element={<Dashboard/>}></Route>
        <Route path="/admin/about" element={<AdminAbout/>}></Route>
      </Route>

      
    </Routes>
  
    </BrowserRouter>
    <ToastContainer/>
    </>
    
  )
}


